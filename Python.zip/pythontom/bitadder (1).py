import gates as g

def bit_adder(a,b,cin):
    fs=g.xor_gate(a,b)
    sum_val = g.xor_gate(fs, cin)

    fco=g.and_gate(a,b)
    fco2 = g.and_gate(fs,cin)
    co = g.or_gate(fco,fco2)

    return sum_val, co

#sum_, carry_o = bit_adder(1,0,0)
#print("The sum is", sum_)
#print("The carry over is",carry_o)
