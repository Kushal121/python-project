import greeting as gt
import dectobin
import gates as g
import bitadder
import reverse
gt.GreatingAtBeginning()

continueLoop=True
while continueLoop==True:
    
    number1=int(input("Enter first decimal number:"))
    number2=int(input("Enter second decimal number:"))
    reverse1 = reverse.reverse(dectobin.dectobin(number1))
    reverse2 = reverse.reverse(dectobin.dectobin(number2))   
    to_valu=[]
    cin=0
    for i in range(len(reverse1)):
        sum_val,co = bitadder.bit_adder(reverse1[i],reverse2[i],cin)
        to_valu.append(sum_val)
        cin=co
            
    print("The sum is", to_valu[::-1])  
    continuous=input("Do you want to continue?? Type 'NO' to exit:")
    if continuous=="no":
        break

print("\n")
gt.GreatingAtEnd()
    
