def GreatingAtBeginning():
    print("\n")
    print("Welcome to the progrmme")
    print("\n")

def GreatingAtEnd():
    print("Thank You for Using the application")
