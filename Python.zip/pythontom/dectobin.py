import reverse
def dectobin(n):
    l=[]
    counter=0
    while counter!=8:
        if n%2==0:
            l.append(0)
        else:
            l.append(1)
        n=n//2
        counter+=1
    l2 = reverse.reverse(l)
    return(l2)
#n=int(input("enter a dec value"))
#print(dectobin(n))
